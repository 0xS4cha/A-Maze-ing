from .MazeGenerator import MazeGenerator
from typing import Any

__all__: Any = [MazeGenerator]
