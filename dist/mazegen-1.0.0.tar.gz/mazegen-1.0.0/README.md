*This project has been created as part
of the 42 curriculum by sservant and julcleme*

# Description
This project is a python project focused on understanding and implementing maze generation and maze solving algorithms by using a graphic library. 

# Algorithms
This project contains two algorithms: `Recursive Backtracking` and `Eller` algorithms.
We choose these algorithms because the `Recursive Backtracking` ensure a perfect maze since it builds the path and never goes back to the pixels already visited.

`Eller`' algorithm is efficient and it uses graphs so its implementation was very interesting. And it could generate non perfect mazes so it was a very good choice

# Instructions
Usage: `python3 a_maze_ing.py config.txt`

# Configuration File
```bash
# this is a comment

# width of the maze
WIDTH=53
# height of the maze
HEIGHT=53

# position of the entry point of the maze (x, y)
ENTRY=1,1
# position of the exit point of the maze (x, y)
EXIT=49,49

# path of the output file
OUTPUT_FILE=output.txt

# the generated maze contains only one solution
PERFECT=0

# view generation and resolving in realtime
ANIMATION=1
```

# Resources
This is the list of the resources used to make this project. 
- [wikipedia.org](https://en.wikipedia.org/wiki/Maze-solving_algorithm) used for the maze solving algorithms
- [wikipedia.org](https://en.wikipedia.org/wiki/Maze_generation_algorithm) used to understand the maze generation techniques
- [emrezorlu.com](https://emrezorlu.com/2012/03/20/maze-creation-solving/) used to understand the differences between the different algorithms
- [professor-l.github.io](https://professor-l.github.io/mazes/) used to visualise concepts behind used algorithms
- [chatgpt.com](https://chatgpt.com) was used to explain us basics of each algorithm. It also helped with colors and the minilib-x library
- [mypy.readthedocs.io](https://mypy.readthedocs.io/en/stable/) documentation for the mypy norm

# Developer Guide

## Package Installation

The maze generator is available as a pip-installable package. You can build it from source:

```bash
make build
```

Then install it:

```bash
pip install mazegen-1.0.0-py3-none-any.whl
```

## Usage Example

```python
from mazegen import MazeGenerator

# Initialize from config file
generator = MazeGenerator("config.txt")

# Generate maze
maze = generator.generate_maze()

# Display (if graphical mode enabled)
generator.draw_maze(maze)

# Solve
solution_path = generator.get_solution(maze)

# Run event loop (keeps window open)
generator.run()
```

## Team

- sservant
- julcleme

Roles:
- sservant: Algorithm implementation (Backtracking, Analysis)
- julcleme: Graphics (MLX), Packaging, Refactoring, Eller's algorithm enhancements

Planning:
We started by researching algorithms, implemented a basic console version, then added MLX graphics. Finally, we refactored repeatedly to meet the modularity requirements and packaging standards.

## Advanced Features
- **Multiple Algorithms**: Configurable via `PERFECT` flag (0 for Eller's, 1 for Backtracking).
- **Graphical Interface**: Interactive buttons for solving/resetting.
- **Continuous Walls**: Post-processing for Eller's algorithm to avoid isolated dots.

## TODO
- [x] You must implement the maze generation as a unique class
- [ ] Use frameworks like pytest or unittest for unit tests, covering edge cases.
- [x] Your functions should handle exceptions gracefully to avoid crashes
- [ ] Use PEP 257 for docstrings
- [x] Use type definition and check using `mypy`
- [x] Makefile using rules `install` `run` `debug` `clean` `lint-strict` and `lint`
- [x] Add a `.gitignore`
- [ ] Create test programs to verify project functionality
- [x] Use venv
- [ ] Fix `makefile`: add install `mlx`
- [x] A default configuration file must be available in your Git repository
- [x] The maze must be randomly generated, but reproducibility via a seed is required
- [ ] You must provide a short documentation describing how to:
	- [ ] Instantiate and use your generator, with at least a basic example.
	- [ ] Pass custom parameters (e.g., `size`, `seed`).
	- [ ] Access the generated structure, and access at least a solution.
- [ ] Fix `README.md`
	- [ ] The complete structure and format of your config file.
	- [ ] The maze generation algorithm you chose.
	- [ ] Why you chose this algorithm.
	- [ ] What part of your code is reusable, and how.
	- [ ] Your team and project management with:
		- [ ] The roles of each team member.
		- [ ] Your anticipated planning and how it evolved until the end
		- [ ] What worked well and what could be improved
		- [ ] Have you used any specific tools? Which ones?
	- [ ] If you implement advanced features (multiple algorithms, display options)describe them in this README.md file
- [x] NO FRENCH :fr:


- [x] This entire reusable module (code and documentation) must be available in a single file
	suitable for a later installation by pip.
	This package must be called mazegen-* and the file must be located at the root of your
	git repository.
	Both .tar.gz and .whl extensions are allowed, as generated by the standard build of a
	Python package.
	Example of a full filename: mazegen-1.0.0-py3-none-any.whl .
	You must provide in you Git repository all needed elements to build the package. This
	will be asked during the evaluation: in a virtualenv or equivalent, install the needed tools
	and build your package again from your sources.
	The main README.md file (not part of the reusable module) must also contain this short
	documentation.